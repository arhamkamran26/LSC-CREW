<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>
<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <center><h3>About us</h3></center>
  <center> <p> <a href="index.php">home</a> / about </p></center>
</div>

<section class="about">

   <div class="flex">

     

      <div class="content">
        <center> <h3>LSC CREW</h3>
<p> Every day in the world’s poorest countries, people die because of a shortage of blood and 
kidney failure due to unhygienic diet. LSC (LIFE SUSTAINING CREW) helps to find your 
nearest location and track your desire blood group and matching kidney in your location. 
Our main goal is to provide easiest way to find your donor insist of rushing everywhere. </p>
<h3>MISSION</h3>
<p>Our mission is to save and improve the lives of people facing kidney failure by increasing the 
quality, speed and number of living donor transplants in the world while protecting all 
living kidney donors
Our mission is also to provide a quality supply of blood components to meet the needs of the 
communities served by The Blood Center, and to provide the technical support needed by the 
blood banking profession to achieve the highest safety and ethical standards.</p>
<a href="contact.php" class="btn">contact us</a></center>
      </div>

   </div>

</section>



<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>