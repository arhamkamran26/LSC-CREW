<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">  

<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
</head>
    <!-- FONT FAMILY UBUNTU OR MONTSERRAT -->
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <!-- BOOTSTRAP AND CSS FILE LINKS -->
    <link rel="stylesheet" href="index.css">
    <script src="js/bootstrap.min.js"></script>
    <title>Life Sustaning Crew</title>
</head>
<body>
<div class="container">
        <nav class="navbar navbar-expand-lg navbar-light fixedtop">
            <a class="navbar-brand ms-5" href="#"><img src="img/logo.png" height="100" width="130" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav mx-auto">
                <li class="nav-item active ms-5">
                  <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item ms-5">
                  <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item ms-5">
                    <a class="nav-link" href="zip.php">Find Donor</a>
                </li>
              
                <li class="nav-item ms-5">
                    <a class="nav-link" href="blooddiease.php">Blood Info</a>
                </li>
                <li class="nav-item ms-5">
                    <a class="nav-link" href="KIDNEY.php">Kidney Info</a>
                </li>
                <li class="nav-item ms-5">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
              </ul>
            </div>
            <div class="button-topbar1">
            <button>Contact Us</button>
            </div>
        </nav>
</div>
