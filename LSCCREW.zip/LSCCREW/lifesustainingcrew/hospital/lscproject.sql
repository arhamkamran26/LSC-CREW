-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2023 at 10:00 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lscproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(1000) NOT NULL,
  `ADDRESS` varchar(1000) NOT NULL,
  `ZIPCODE` int(11) NOT NULL,
  `PHONE` varchar(100) NOT NULL,
  `URL` varchar(1000) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`ID`, `NAME`, `ADDRESS`, `ZIPCODE`, `PHONE`, `URL`, `email`, `password`) VALUES
(1, 'Aamir Gaziani', 'Main University Road, Karachi', 75290, '+92.03033327328', '', 'aamirgaziani969@gmail.com', '6325ae85d932504df031'),
(2, 'Dow Hospital', 'Suparco Road , Karachi', 75230, '+9212345678', 'https://dowhospital.com/', 'info@dow.com', '7b7e91331e041cc7a014');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `ADDRESS` varchar(1000) NOT NULL,
  `ZIP` int(11) NOT NULL,
  `PHONE` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `PASS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`ID`, `NAME`, `ADDRESS`, `ZIP`, `PHONE`, `EMAIL`, `PASS`) VALUES
(1, 'Aamir Gaziani', 'Main University Road, Karachi', 75290, '+92.03033327328', 'aamirgaziani969@gmail.com', '6325ae85d932504df0319223a2d5e7e7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
