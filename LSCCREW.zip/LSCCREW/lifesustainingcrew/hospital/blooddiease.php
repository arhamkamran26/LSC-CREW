<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>
<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet">

</head>
<body>
   
<?php include 'header.php'; ?>
<div class="container">
<div class="heading">
   <center><h3>BLOOD </h3></center>
<p>Blood is a crucial fluid in the human body that circulates through the circulatory system, carrying 
essential substances to various organs and tissues. It is responsible for several vital functions, 
including:</p>
<center><h4>Oxygen and Nutrient Transport:</h4></center>
<p> One of the primary functions of blood is to transport 
oxygen from the lungs to all the body's cells and tissues. It also carries essential nutrients, such 
as glucose and fatty acids, derived from the food we eat to provide energy to the cells.
</p>
<center><h4> Waste Removal:</h4></center>
<p> Blood helps in the removal of waste products, such as carbon dioxide and 
urea, from the cells and tissues. Carbon dioxide is transported back to the lungs, where it is 
eliminated from the body during respiration.</p>
<center><h4>. Immune Response:</h4></center>
<p>Blood contains white blood cells, which are a crucial part of the 
immune system. These cells help the body defend against infections, viruses, bacteria, and other 
foreign substances that may harm the body.
</p>
<center><h4>. Temperature Regulation:</h4></center>
<p> Blood plays a role in regulating body temperature. When the 
body is too hot, blood vessels dilate, allowing more blood to flow close to the skin's surface to 
release heat. Conversely, when the body is too cold, blood vessels constrict to reduce heat loss.
</p>
<center><h4> Clotting and Wound Healing:</h4></center>
<p>: Platelets in the blood are responsible for clotting when a 
blood vessel is injured. This helps prevent excessive bleeding and aids in wound healing</p>
<p>Blood is composed of several components:</p>
<center><h5>. Plasma:</h5></center>
<p>Plasma makes up about 55% of the blood and is a pale yellow liquid containing 
water, electrolytes, proteins (including clotting factors and antibodies), hormones, and waste 
products.</p>
<center>><h2>FOR DETAIL PDF</h2>
<div class="button-topbar1">
        
            <embed src="Blood.pdf" type="application/pdf">
            <br>
         <a href="blood.pdf">Click here</a>
            </div>
            </center>
</div>
</div>
</html>
<?php
include('footer.php');
?>
<!-- for footer -->