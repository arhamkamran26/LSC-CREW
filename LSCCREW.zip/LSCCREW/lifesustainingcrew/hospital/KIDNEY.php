<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>
<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet">

</head>
<body>
   
<?php include 'header.php'; ?>
<div class="container">
<div class="heading">
   <center><h3>KIDNEY </h3></center>
   <center><h4>What are the kidneys? </h4></center>
<p>The kidneys are two bean-shaped organs that filter your 
blood. Your kidneys are part of your urinary system.
Your kidneys filter about 200 quarts of fluid every day —
enough to fill a large bathtub. During this process, your 
kidneys remove waste, which leaves your body as urine 
(pee). Most people pee about two quarts daily. Your body 
re-uses the other 198 quarts of fluid.
Your kidneys also help balance your body’s fluids 
(mostly water) and electrolytes. Electrolytes are essential 
minerals that include sodium and potassium.:</p>
<center><h4>Who is at the greatest risk of kidney problems?
</h4></center>
<p> People with diabetes or high blood pressure have the 
highest risk of kidney problems. Accidents or trauma can 
also harm your kidneys, such as car accidents or sports 
injuries.
</p>
<center><h4> What do the kidneys do?
</h4></center>
<p> Your kidneys have many important functions. They clean 
toxins and waste out of your blood. Common waste 
products include nitrogen waste (urea), muscle waste 
(creatinine) and acids. </p>

<center>><h2>FOR DETAIL PDF</h2>
<div class="button-topbar1">
        
            <embed src="KIDNEY.pdf" type="application/pdf">
            <br>
         <a href="KIDNEY.pdf">Click here</a>
            </div>
            </center>
</div>
</div>
</html>
<?php
include('footer.php');
?>
<!-- for footer -->