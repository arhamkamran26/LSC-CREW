


<?php include('config.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>contact</title>

   <!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>


<div class="container-fluid bg-primary my-5 py-5">
        <div class="container py-5">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h5 class="d-inline-block text-white text-uppercase border-bottom border-5">You Searching Any Donar?</h5>
                <h1 class="display-4 mb-4">SELECT ZIP CODE OF YOUR AREA</h1>
                <h5 class="text-white fw-normal">WE ARE HERE TO HELP YOU FIND OUT YOU DESIRE DONOR FOR SAVING YOUR LIFE.</h5>
            </div>
            <div class="mx-auto" style="width: 100%; max-width: 600px;">
            <form action="SEARCH.PHP" method="POST" class="pl-3 pt-3">
                <div class="input-group">
                    <select class="form-select border-primary w-25" style="height: 60px;" name="zipcodes" id="">
                <option disabled selected>ZIP CODES</input>
              <?PHP
              $qry = "SELECT ZIPCODE FROM hospitals";
              $res = mysqli_query($conn, $qry);
              while($row = mysqli_fetch_assoc($res))
              {
              ?>
              <option value="<?PHP echo $row['ZIPCODE']; ?>"><?PHP echo $row['ZIPCODE']; ?></option>
              <?PHP
              }
              ?>
                    </select>
                    <!-- <input type="text" class="form-control border-primary w-50" placeholder="Write Your Aeea Code here"> -->
                    <!-- <button class="btn btn-dark border-0 w-25">Search</button> -->
                    <input type="submit" class="btn btn-dark border-0 w-25" name="submit" value="Search" id="">
                </div>
                </form>
            </div>
        </div>
    </div>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>

