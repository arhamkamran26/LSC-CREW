<?php

$conn = mysqli_connect('localhost','root','','lscproject') or die('connection failed');

?>