<?php

include ('config.php');

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
   $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
   $phone = mysqli_real_escape_string($conn, $_POST['phone']);
   $url = mysqli_real_escape_string($conn, $_POST['link']);
   $address = mysqli_real_escape_string($conn, $_POST['address']);
   $zipcode = mysqli_real_escape_string($conn, $_POST['zip']);
   // $user_type = $_POST['user_type'];

   $select_users = mysqli_query($conn, "SELECT * FROM `hospitals` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select_users) > 0){
      $message[] = 'user already exist!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         mysqli_query($conn, "INSERT INTO `hospitals`(NAME , email, password , PHONE, URL , ADDRESS, ZIPCODE) VALUES('$name', '$email', '$cpass','$phone', '$url','$address','$zipcode')") or die('query failed');
         $message[] = 'registered successfully!';
         header('location:index.php');
      }
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/loginstyle.css">

</head>
<body>



<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
   
<div class="form-container">

   <form action="" method="post">
      <h3>KIDNEY DONATION</h3>
      <input type="text" name="name" placeholder="Your Name" required class="box">
      <input type="email" name="email" placeholder="Your Email" required class="box">
      <input type="password" name="password" placeholder="Enter password" required class="box">
      <input type="password" name="cpassword" placeholder="confirm your password" required class="box">
      <input type="tel" name="phone" placeholder="Your number" required class="box">
      <input type="text" name="link" placeholder="Have any website(Optional)" class="box">
      <input type="text" name="address" placeholder="Your address" required class="box">
      <input type="tel" name="zip" placeholder="ZIPCODE" required class="box">
      <!-- <select name="user_type" class="box">
         <option value="user">user</option>
         <option value="hospital">hospital</option>
      </select> -->
      <input type="submit" name="submit" value="Donate" class="btn">
   </form>

</div>

</body>
</html>